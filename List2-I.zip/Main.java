import java.scanner;
class Main {

  public static void main(String[] args) {
  Scanner ler = new Scanner(system.in);

    int opcaoP, numPar;
    double totalG=0;

    System.out.println("Digite o total gasto");
    totalG = ler.nextDouble();

    while(totalG != -1) {

        System.out.println("Selecione uma das opções de pagamento");
        System.out.println("1 - À vista com 10% de desconto");
        System.out.println("2 - Parcelado 2x (preço da etiqueta)");
        System.out.println("Parcelado de 3x até 6x com 3% de juros ao mês (somente para compras acima de R$ 500,00 - inclusive)");

      opcaoP= ler.nextInt();

      switch(opcaoP){
        case 1:
          System.out.println("Valor total à vista: R$ " + totalG * 0,9);
          break;

        case 2:
          System.out.println("Valor total parcelado de 2x: R$ " + totalG/2);
          break;

        case 3:
          {
              if(totalG>=500)
              {
                System.out.println("Insira o numero de parcelas desejadas");
                numPar = ler.nextInt();

                if(numPar >= 3 & numPar <= 6)
                {
                  System.out.printf("Valor total parcelado: %.2f, em %d parcelas de: R$ %.2f \n" , totalG * 1.03 , numPar , (totalG*1.03)/numPar);
                }
                else
                {
                  System.out.println("Número de parcela invalido");
                }
                
              }
            else
              {
                System.out.println("Escolha nova forma de pagamento");
              }
                break;
          }
          
      
      default :
        System.out.println("Opção inválida");

      }
    }
    System.out.println("Insira o total gasto");
    totalG = ler.nextInt();
  }
}